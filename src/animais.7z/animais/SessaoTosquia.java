/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animais;

/**
 *
 * @author formando
 */
public class SessaoTosquia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Tosquiador t1=new Tosquiador();
        Ovelha o1=new Ovelha();
        t1.tosquiar(o1);
    }
    
}
